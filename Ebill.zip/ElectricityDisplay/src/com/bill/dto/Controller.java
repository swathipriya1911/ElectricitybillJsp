package com.bill.dto;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bill.bean.ElectricityBillBean;
import com.bill.bean.ElectricityConsumerBean;
import com.bill.exception.MyException;
import com.bill.service.ElectricityBillServImpl;
import com.bill.service.IElectricityBillService;
import com.sun.org.apache.bcel.internal.generic.LSTORE;

/**
 * Servlet implementation class Controller
 */
@WebServlet("/Controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String option=request.getParameter("action");
		PrintWriter out=response.getWriter();
		if(option.equals("login"))
		{
			if(request.getParameter("uName").equals("admin")&&request.getParameter("pass").equals("admin"))
			{
				getServletContext().getRequestDispatcher("/user_info.jsp").forward(request,response);
			}
		}
		else if(option.equals("Calculate Bill"))
		{
		int consumerNumber=Integer.parseInt(request.getParameter("cNumber"));
		float lastMonMeterRead=Float.parseFloat(request.getParameter("lastMonReading"));
		float currentMonMeterRead=Float.parseFloat(request.getParameter("currentMonReading"));
		final float FIXEDCHARGES=100f; 
		float units,netAmount=0;
		IElectricityBillService ibill=new ElectricityBillServImpl();
		response.setContentType("text/html");
	out=response.getWriter();
		ElectricityConsumerBean cons=ibill.isValidConsumerNum(consumerNumber);
		if(cons!=null)
		{	
			if(currentMonMeterRead<lastMonMeterRead){
				//out.println("Invalid Meter Reading");
				request.setAttribute("error",new MyException("Invalid Meter Reading"));
				getServletContext().getRequestDispatcher("/Error_info.jsp").forward(request,response);
				}
				else
				{
					units=(currentMonMeterRead-lastMonMeterRead);
					netAmount=(float) (units*1.15+FIXEDCHARGES);
					ElectricityBillBean bill=new ElectricityBillBean();
					bill.setConsNumber(cons.getConsNumber());
					bill.setCurMonMeterRead(currentMonMeterRead);
					bill.setNetAmount(netAmount);
					bill.setUnits(units);
					ibill.addBillDetails(bill);
					request.setAttribute("bill",bill);
					request.setAttribute("consumer",cons);
					getServletContext().getRequestDispatcher("/BillInfo.jsp").forward(request,response);
					
				}
		}

		else{
			//out.println("invalid consumer number");
			request.setAttribute("error",new MyException("No Bill Details Found for customer number:"+consumerNumber));
			getServletContext().getRequestDispatcher("/Error_info.jsp").forward(request,response);
		}
	}
		else if(option.equals("listCust"))
		{
			IElectricityBillService ibill=new ElectricityBillServImpl();
			List<ElectricityConsumerBean> listBean=ibill.getDetails();
			request.setAttribute("conslist",listBean);
			getServletContext().getRequestDispatcher("/listCust.jsp").forward(request,response);
		}
		else if(option.equals("searchCust"))
		{
			getServletContext().getRequestDispatcher("/search.jsp").forward(request,response);
		}
		else if(option.equals("showcustomer"))
		{
			int consumerNumber=Integer.parseInt(request.getParameter("consumernum"));
			IElectricityBillService ibill=new ElectricityBillServImpl();
			ElectricityConsumerBean cons=ibill.getCustomer(consumerNumber);
			if(cons!=null)
			{	
			request.setAttribute("custdetails",cons);
			getServletContext().getRequestDispatcher("/custInfo.jsp").forward(request,response);
			}
			else
			{
				request.setAttribute("error",new MyException("Invalid Consumer Number"));
				getServletContext().getRequestDispatcher("/Error_info.jsp").forward(request,response);
			}
		}
		else if(option.equals("showdetails"))
		{
			int consumerNumber=Integer.parseInt(request.getParameter("consumernum"));
			IElectricityBillService ibill=new ElectricityBillServImpl();
			ElectricityConsumerBean cons=ibill.isValidConsumerNum(consumerNumber);
			if(cons!=null)
			{	
			List<ElectricityBillBean> listbill=ibill.getBillDetails(consumerNumber);
			request.setAttribute("billdetails",listbill);
			getServletContext().getRequestDispatcher("/Showbill.jsp").forward(request,response);
			}
			else
			{
				request.setAttribute("error",new MyException("No Bill Details Found for customer number:"+consumerNumber));
				getServletContext().getRequestDispatcher("/Error_info.jsp").forward(request,response);
			}
		}
}
}