package com.bill.service;

import java.util.List;

import com.bill.bean.ElectricityBillBean;
import com.bill.bean.ElectricityConsumerBean;

public interface IElectricityBillService {

	void addBillDetails(ElectricityBillBean bill);

	ElectricityConsumerBean isValidConsumerNum(int consumerNumber);

	List<ElectricityConsumerBean> getDetails();

	List<ElectricityBillBean> getBillDetails(int consumerNumber);

	ElectricityConsumerBean getCustomer(int consumerNumber);

}
