package com.bill.service;

import java.util.List;

import com.bill.bean.ElectricityBillBean;
import com.bill.bean.ElectricityConsumerBean;
import com.bill.dao.ElectricityDAOImpl;
import com.bill.dao.IElectricityDAO;

public class ElectricityBillServImpl implements IElectricityBillService{

	@Override
	public void addBillDetails(ElectricityBillBean bill) {
		IElectricityDAO ibilldao=new ElectricityDAOImpl();
		ibilldao.addBillDetails(bill);
	}

	@Override
	public ElectricityConsumerBean isValidConsumerNum(int consumerNumber) {
		IElectricityDAO ibilldao=new ElectricityDAOImpl();
		return ibilldao.isValidConsumer(consumerNumber);
		
	}

	@Override
	public List<ElectricityConsumerBean> getDetails() {
		IElectricityDAO ibilldao=new ElectricityDAOImpl();
		return ibilldao.getDetails();
	}

	@Override
	public List<ElectricityBillBean> getBillDetails(int consumerNumber) {
		IElectricityDAO ibilldao=new ElectricityDAOImpl();
		return ibilldao.getBillDetails(consumerNumber);
	}

	@Override
	public ElectricityConsumerBean getCustomer(int consumerNumber) {
		IElectricityDAO ibilldao=new ElectricityDAOImpl();
		return ibilldao.getCustomer(consumerNumber);
	}

}
