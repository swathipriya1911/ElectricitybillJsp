package com.bill.dao;

import java.util.List;

import com.bill.bean.ElectricityBillBean;
import com.bill.bean.ElectricityConsumerBean;

public interface IElectricityDAO {

	ElectricityConsumerBean isValidConsumer(int consumerNumber);

	void addBillDetails(ElectricityBillBean bill);

	List<ElectricityConsumerBean> getDetails();

	List<ElectricityBillBean> getBillDetails(int consumerNumber);

	ElectricityConsumerBean getCustomer(int consumerNumber);

}
